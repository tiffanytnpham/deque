package hw1_proj;

import java.util.ArrayList;
import java.util.NoSuchElementException;


public class Deque {
	
	/* 
	 * Nested inner class, that holds the Nodes of the Deque
	 */
	private static class Node {
		int data;
		Node next;
		Node prev;
		
		public Node(int i) {
			data = i;
			next = null;
			prev = null;
		}
	}
	
	
	private Node head; //front of the Deque
	private Node tail; //back of the Deque
	
	public Deque() {
		head = null;
		tail = null;
	}
	
	/*
	 * Returns true if the Deque is empty (contains no Nodes). Returns true otherwise.
	 */
	public boolean isEmpty() {
		return head==null&&tail==null;
	}
	
	/*
	 * Converts an Deque to an ArrayList. 
	 * This method is useful for testing.
	 */
	public ArrayList<Integer> toArrayList(){
		ArrayList<Integer> deq = new ArrayList<>();
		Node current = head;
		while(current!=null) {
			deq.add(current.data);
			current = current.next;
		}
		return deq;
	}
	
	/*
	 * Returns a String representation of the Deque.
	 * This method is useful for testing.
	 */
	public String toString() {
		String s = "";
		if(isEmpty())
			return s;
		Node current = head;
		while(current!=null) {
			s = s+current.data + ",";
			current = current.next;
		}
		return s.substring(0,s.length()-1);
	}
	
	/* *******************************************************************************
	 * 
	 *                               ADD YOUR METHODS HERE
	 * 
	 *********************************************************************************/
	
	
	/*
	 * Inserts a new Node in the Deque,
	 * with int i as the new head.
	 */
	public void insertHead(int i) {
		Node newNode = new Node(i);
		if(head == null) {
			tail = head = newNode;
		}
		else {
			newNode.next = head;
			head.prev = newNode;
			head = newNode;
		}
	}
	
	/*
	 * Inserts a new Node in the Deque,
	 * with int i as the new tail. 
	 */
	public void insertTail(int i) {
		Node newNode = new Node(i);
		if( tail == null) {
			head = tail = newNode;
		}
		else  {
			newNode.prev = tail;
			tail.next= newNode;
			tail = newNode;
		}
	}
	
	/*
	 * Removes the current head of the Deque.
	 * updates the head to the next node.
	 */
	public int removeHead() {
		
		if (isEmpty()) 
			throw new NoSuchElementException();
		
		Node temp = head;
		if(head == null) 
			tail = null;
		else 
			head = head.next;
			head.prev = null;
		
		return temp.data;
	}
	
	/*
	 * Removes the current tail of the Deque.
	 * updates the head to the previous node.
	 */
	public int removeTail() {
		
		if (isEmpty()) 
			throw new NoSuchElementException();
		
		Node temp = tail;
		if(tail == null) 
			head = null;
		else 
			tail = tail.prev;
			tail.next = null;
		
		
		return temp.data;
	}

	/*
	 * Returns the value of the head in Deque.
	 */
	public int peekHead() {
		if (isEmpty()) 
			throw new NoSuchElementException();
			
		return head.data;
	}
	
	/*
	 * Returns the value of the tail in Deque.
	 */
	public int peekTail() {
		if (isEmpty()) 
			throw new NoSuchElementException();
			
		return tail.data;
	}
	
	/*
	 * Sorts Deque in ascending order.
	 */
	public Deque sort() {
		Deque sortedD = new Deque();
		ArrayList<Integer> current = toArrayList();
		int size = current.size();
		
		for(int i = 0; i < size; i++) {
			for(int j = 0; j < size - 1; j++) {
				if(current.get(j) > current.get(j + 1)) {
					int temp = current.get(j);
					current.set(j, current.get(j + 1));
					current.set(j+ 1, temp);
				}
			}
		}
		
		for(int i = 0;  i < size; i++) {
			sortedD.insertTail(current.get(i));
		}
		return sortedD;
	}
}