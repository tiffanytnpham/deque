package hw1_proj;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.NoSuchElementException;

import org.junit.BeforeClass;
import org.junit.Test;

public class DequeTest {
	
	static ArrayList<Integer> toCompareOne;
	static ArrayList<Integer> toCompareMany;
	static ArrayList<Integer> sorted;
	
	 @BeforeClass
	    public static void setup() {
		 toCompareOne = new ArrayList<>();
		 toCompareOne.add(1);
		 
		 toCompareMany = new ArrayList<>();
		 for(int i=0;i<10;i++) {
			 toCompareMany.add((int)(Math.random()*i));
		 }
		 
		 sorted=new ArrayList<>();
		 for(int i=0;i<5;i++) {
			 sorted.add(i);
		 }
		 
		 
	    }
	

	@Test
	public void oneElement() {
		Deque one = new Deque();
		one.insertHead(1);
		
		assertEquals(one.toArrayList(),toCompareOne);
	}
	
	@Test
	public void ManyElementsTail() {
		Deque many = new Deque();
		for(int i:toCompareMany)
			many.insertTail(i);
		assertEquals(many.toArrayList(),toCompareMany);
	}
	
	@Test(expected = NoSuchElementException.class)
	public void removeHeadFromEmpty() {
		Deque empty = new Deque();
		empty.removeHead();
 	}
	
	@Test 
	public void sorted() {
		Deque notSorted = new Deque();
		for(int i: sorted) {
			notSorted.insertHead(i);
		}
		Deque sortTest = notSorted.sort();
		assertEquals(sortTest.toArrayList(),sorted);
	}
	
	@Test
	public void addHead() {
		Deque newHead = new Deque();
		newHead.insertHead(3);
 	}
	
	@Test
	public void addTail() {
		Deque newTail = new Deque();
		newTail.insertTail(3);
 	}
	
	@Test
	public void empty() {
		Deque empty = new Deque();
		empty.isEmpty() ;
 	}
	
	@Test(expected = NoSuchElementException.class)
	public void removeTailFromEmpty() {
		Deque empty = new Deque();
		empty.removeTail();
 	}
	
	@Test
	public void peekHead() {
		Deque newD = new Deque();
		newD.insertHead(1);
		newD.insertHead(2);
		newD.insertHead(3);
		int head = newD.peekHead();
		assertEquals(newD.peekHead(), head);
 	}
	
	@Test
	public void peekTail() {
		Deque newD = new Deque();
		newD.insertHead(1);
		newD.insertHead(2);
		newD.insertHead(3);
		int tail = newD.peekTail();
		assertEquals(newD.peekTail(), tail);
 	}
	
	@Test
	public void remHead() {
		Deque newD = new Deque();
		newD.insertHead(1);
		newD.insertHead(2);
		newD.removeHead();
		assertEquals(newD.toArrayList(), toCompareOne);
 	}
	
	@Test
	public void remTail() {
		Deque newD = new Deque();
		newD.insertHead(1);
		newD.insertTail(2);
		newD.removeTail();
		assertEquals(newD.toArrayList(), toCompareOne);
 	}

}
